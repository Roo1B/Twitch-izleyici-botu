# Twitch İzleyici Botu

#### Kutuların renk kodları

⬛ - Instance is spawned.    🟨 - Instance is buffering.    🟩 - Instance is actively watching.
 
#### Çalışma
![](docs/instances_spawning.gif)  
(  aktiflik olmaz ise tarayıcı pencereleri görünmez olur)

1. Zip dosyasını bir klasöre çıkarın.
2. proxy/proxy_list.txt dosyasına kendi proxy'lerinizi ekleyin
3. Yürütülebilir dosyayı başlatın ve GUI'yi bekleyin.
4. Örnekleri sabırla ortaya çıkarın.

#### Kutular ile etkileşimler
🖱️ Sol tıklama: Sayfayı yenile.
🖱️ Sağ tıklayın: Örneği yok edin.
🖱️ Sol tıklama + CTRL: Ekran görüntüsü al (kök klasöre kaydedilir).




